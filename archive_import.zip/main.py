import utils
import models
from utils import DIRS
from termcolor import colored

for dir in DIRS:
    csv_info = utils.get_from_csv(dir=dir)
    print(colored("************* READ CSV INFORMAITION **************","green"))
    connection_string = models.connect_to_mongo(collection_name='info_entity')
    copied_file = models.add_files_to_collection(dir=dir,connection_string=connection_string, csv_info=csv_info)
    print(colored(f"************* INSERTED DATA OF DIRECTORY {dir} TO MONGO **************", "green"))

print(colored(f"COPIED FILES: \n{copied_file}","yellow"))
